DROP TABLE student_status;<|||||||>

CREATE TABLE `student_status` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `stdstatus_id` int(10) NOT NULL,
  `stdstatus_name` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;<|||||||>




